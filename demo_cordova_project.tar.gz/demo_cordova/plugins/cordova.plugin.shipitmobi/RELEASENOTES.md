# Release Notes

### 1.0.0 (Aug 1, 2015)
* Added support for android
