cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "file": "plugins/cordova.plugin.shipitmobi/www/SIMPlugin.js",
        "id": "cordova.plugin.shipitmobi.SIMPlugin",
        "clobbers": [
            "SIMPlugin"
        ]
    }
];
module.exports.metadata = 
// TOP OF METADATA
{
    "cordova-plugin-whitelist": "1.2.2",
    "cordova.plugin.shipitmobi": "1.0.0"
}
// BOTTOM OF METADATA
});